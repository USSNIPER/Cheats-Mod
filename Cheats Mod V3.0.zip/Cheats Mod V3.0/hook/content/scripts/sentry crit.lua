if CommandManager.config["sentry_crit"] then
	function SentryGunWeapon:crit_chance(col_ray, damage)
		local target = self.sentry_crit_target
		local char_dmg = alive(target) and target.character_damage and target:character_damage()
		local owner = char_dmg and char_dmg.roll_critical_hit and self._unit:base():get_owner()
	
		if alive(owner) and owner == managers.network:session():local_peer():unit() then
			local crit, crit_damage = char_dmg:roll_critical_hit({
				variant = "bullet",
				damage = damage,
				weapon_unit = self._unit,
				attacker_unit = owner,
				col_ray = col_ray,
				armor_piercing = self._use_armor_piercing,
				origin = owner:position(),
				critical_hit = true
			}, damage)
			
			return crit, crit_damage
		end
		return false, damage
	end
	
	local orig_apply_dmg_mul = SentryGunWeapon._apply_dmg_mul
	function SentryGunWeapon:_apply_dmg_mul(damage, col_ray, ...)
		local damage_result = {orig_apply_dmg_mul(self, damage, col_ray, ...)}
		local crit, crit_damage = self:crit_chance(col_ray, damage_result[1])

		return crit and crit_damage or unpack(damage_result)
	end
	
	local orig_fire_raycast = SentryGunWeapon._fire_raycast
	function SentryGunWeapon:_fire_raycast(from_pos, direction, shoot_player, target_unit, ...)
		self.sentry_crit_target = target_unit
		return orig_fire_raycast(self, from_pos, direction, shoot_player, target_unit, ...)
	end
end