CommandManager:vis("crash_fix")

if RequiredScript == "lib/network/handlers/unitnetworkhandler" then
    CommandManager:vis("anticrash")
end