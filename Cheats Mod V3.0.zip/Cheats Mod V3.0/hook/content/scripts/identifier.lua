--[[local class_name = "Hook Identifier"
local loaded = rawget(_G, class_name)
local c = loaded or rawset(_G, class_name, {recived_peers = {}}) and _G[class_name]

if not loaded then
	-- check players recently played with (if reconnecting after entering menu and such)
	function c:is_recent(user_id)
		for _, user in ipairs(Steam:logged_on() and Steam:friends() or {}) do
			if user:id() == user_id then
				return true
			end
		end
	end
end

local orig_set_outfit_string = NetworkPeer.set_outfit_string
function NetworkPeer:set_outfit_string(...)
	local session = managers.network:session()
	local local_peer = session and session:local_peer()

	if local_peer and self ~= local_peer then
		DelayedCalls:Add(class_name .. self:id(), 2, function()
			LuaNetworking:SendToPeer(self:id(), class_name, tostring(local_peer:id()))
		end)
	end

	return orig_set_outfit_string(self, ...)
end

--receive as client/host
Hooks:Add("NetworkReceivedData", class_name, function(peer_id, id, data)
	if id == class_name and data and #data == 1 then
		local sender = managers.network:session():peer(tonumber(data))
		local user_id = sender and sender:user_id()

		if user_id and c.recived_peers[user_id] == nil then
			c.recived_peers[user_id] = true

			if not c:is_recent(user_id) then
				managers.chat:_receive_message(1, class_name, string.format("Detected from %s.", sender:name()), Color.green)
			end
		end
	end
end)--]]