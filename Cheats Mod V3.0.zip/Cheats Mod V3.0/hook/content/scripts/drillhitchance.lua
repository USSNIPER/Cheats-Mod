if CommandManager.config["trainer_buffs"] then
	--You dont require kickstarter skill to hit drill with melee
	local orig_func_init = PlayerStandard.init
	function PlayerStandard:init(unit)
		orig_func_init(self, unit)
		self._on_melee_restart_drill = true
	end

	--Gives all drill upgrades except kickstarter
	local orig_func_Drill_init = Drill.init
	function Drill:init(unit)
		orig_func_Drill_init(self, unit)
		self._skill_upgrades = {
			auto_repair_level_1 = 1,
			auto_repair_level_2 = 1,
			speed_upgrade_level = 2,
			silent_drill = true,
			reduced_alert = true
		}
		managers.network:session():send_to_peers_synched("sync_drill_upgrades", self._unit, self._skill_upgrades.auto_repair_level_1, self._skill_upgrades.auto_repair_level_2, self._skill_upgrades.speed_upgrade_level, self._skill_upgrades.silent_drill, self._skill_upgrades.reduced_alert)
	end

	function Drill.get_upgrades(drill_unit, player)
		local is_drill = drill_unit:base() and drill_unit:base().is_drill
		local is_saw = drill_unit:base() and drill_unit:base().is_saw

		if is_drill or is_saw then
			return {
				auto_repair_level_1 = 1,
				auto_repair_level_2 = 1,
				speed_upgrade_level = 2,
				silent_drill = true,
				reduced_alert = true
			}
		end
	end
	
	--you get 100% chance repair/upgrade drill on melee hit and Lower drill timer as you melee it
	function Drill:on_melee_hit(peer_id)
		local unit = self._unit
		local session = managers.network:session()

		if unit:timer_gui()._jammed then
			if not self:_does_peer_exist(peer_id) then
				local skills = self._skill_upgrades

				table.insert(self._peer_ids, peer_id)
				if Network:is_client() then
					session:send_to_host("sync_unit_event_id_16", unit, "base", Drill.EVENT_IDS.melee_restart_client)
				else
					self:on_melee_hit_success()
				end
				unit:set_skill_upgrades(skills)
				session:send_to_peers_synched("sync_drill_upgrades", unit, skills.auto_repair_level_1, skills.auto_repair_level_2, skills.speed_upgrade_level, skills.silent_drill, skills.reduced_alert)
			end
		else
			local decrease = 10
			local gui_timer = unit:timer_gui()
			local timer = unit:base() and gui_timer and gui_timer._current_timer
			local floor = math.floor(timer or -1)

			if timer and floor ~= -1 and floor > decrease then
				local newvalue = timer - decrease

				gui_timer:_start(newvalue)
				if session then
					session:send_to_peers_synched("start_timer_gui", gui_timer._unit, newvalue)
				end
			end
		end

		if unit:timer_gui()._jammed then
			unit:timer_gui():set_jammed(false)
		end
	end
end