if CommandManager.config["intimidate_units"] and not Network:is_client() then
	local mod_name = "dominate everyone"  
	local loaded = rawget(_G, mod_name)
	local c = loaded or rawset(_G, mod_name, {}) and _G[mod_name] 

	if not loaded then
		c.orig_unit_leave_group = GroupAIStateBase.unit_leave_group

		-- fixes [string "lib/managers/group_ai_states/groupaistatebase..."]:4720: attempt to index local 'group' (a nil value)
		function GroupAIStateBase:unit_leave_group(unit, ...)
			local brain = alive(unit) and unit:brain()

			if brain and brain._logic_data.group then
				c.orig_unit_leave_group(self, unit, ...)
			end
		end
	end

	c.orig_convert_to_criminal = c.orig_convert_to_criminal or CopBrain.convert_to_criminal

	tweak_data.upgrades.values.player.convert_enemies_max_minions = {99, 99} -- max 198 converts when aced
	CopLogicIdle.on_intimidated = CopLogicIdle._surrender -- dom specials

	-- reapply shield to shields
	function CopBrain:convert_to_criminal(...)
		c.orig_convert_to_criminal(self, ...)
		self._unit:movement():add_weapons()

		local base = self._unit:base()

		if base:has_tag("shield") then
			self._unit:inventory():shield_unit():set_enabled(true)

			if base:has_tag("phalanx_vip") then
				CopLogicPhalanxVip.breakup()
			end
		end
	end

	function CopBrain:on_intimidated(amount, aggressor_unit)
		local interaction_voice = self:interaction_voice()

		if interaction_voice then
			self:set_objective(self._logic_data.objective.followup_objective)

			return interaction_voice
		else
			local inventory, effect = self._unit:inventory()

			if inventory and inventory:shield_unit() then
				self._logic_variants[self._unit:base()._tweak_table].intimidated = CopLogicIntimidated -- dom shields

				if self._unit:base():has_any_tag({"phalanx_vip", "phalanx_minion"}) then
					amount = 8
				end
			end

			self._current_logic.on_intimidated(self._logic_data, amount, aggressor_unit)
		end
	end
end

if GroupAIStateBase and CommandManager.config["intimidate_units"] then
	-- inf hostages
	function GroupAIStateBase:has_room_for_police_hostage()
		return true
	end
end--]]