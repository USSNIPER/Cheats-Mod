--update spoofname
local mod_name = "character_spoofer_by_mayzone"

if not CommandManager or not CommandManager.config or not CommandManager.config.fake_name then
	return
end

CommandManager.config.real_name = Steam:username()
CommandManager:Save()

local spoofname = CommandManager.config.fake_name
local spooflvl = CommandManager.config.fake_level
local spoofrank = CommandManager.config.fake_rank

local function load_data()
	local current_level = managers.experience:current_level()
	local current_rank = managers.experience:current_rank()

	if CommandManager.config.real_level ~= current_level or CommandManager.config.real_rank ~= current_rank then
		CommandManager.config.real_level = current_level
		CommandManager.config.real_rank = current_rank
		CommandManager:Save()
	end
	
	if CommandManager.config.first_load then		
		spoofname = CommandManager.config.real_name
		spoofrank = CommandManager.config.real_rank
		spooflvl = CommandManager.config.real_level
		
		CommandManager.config.first_load = false
		CommandManager.config.fake_name = spoofname
		CommandManager.config.fake_level = spooflvl
		CommandManager.config.fake_rank = spoofrank
		CommandManager:Save()
	end

	local loaded = rawget(_G, mod_name)
	local c = loaded or rawset(_G, mod_name, {}) and _G[mod_name]
	if not loaded then
		-- spoof crimenet name
		local SteamClass = getmetatable(Steam)
		if SteamClass then
			local orig_username = SteamClass.username
			function SteamClass:username(userid, ...)
				if not CommandManager.config.first_load and (not userid or (userid and userid == SteamClass.userid(Steam))) then
					return CommandManager.config.fake_name
				end
				return orig_username(self, userid, ...)
			end
		end
	end
end

local function update_everyones_hud()
	local session = managers.network and managers.network:session()

	if not session then
		return
	end
	
	local me = session:local_peer()
	local character = me:character()
	local level = CommandManager.config.spoof_level and CommandManager.config.fake_level or managers.experience:current_level()
	local rank = CommandManager.config.spoof_rank and CommandManager.config.fake_rank or managers.experience:current_rank()

	--updates instantly
	me:set_name(CommandManager.config.fake_name)
	managers.network:session():send_to_peers_except(me, "request_player_name_reply", CommandManager.config.fake_name)
	managers.network:session():send_to_peers_except(me, "lobby_info", level, rank, managers.infamy:selected_join_stinger_index(), character, "remove")
	managers.network:session():send_to_peers_except(me, "sync_profile", level, rank)

	--lobby/briefing update player slot
	local lobby_menu = managers.menu:get_menu("lobby_menu")

	if lobby_menu and lobby_menu.renderer:is_open() then
		lobby_menu.renderer:_set_player_slot(me:id(), {
			name = me:name(),
			peer_id = me:id(),
			level = level,
			rank = rank,
			character = character
		})
	end

	local kit_menu = managers.menu:get_menu("kit_menu")

	if kit_menu and kit_menu.renderer:is_open() then
		kit_menu.renderer:_set_player_slot(me:id(), {
			name = me:name(),
			peer_id = me:id(),
			level = level,
			rank = rank,
			character = character
		})
	end

	--works in game
	if managers.hud then
		managers.hud:set_teammate_name(HUDManager.PLAYER_PANEL, CommandManager.config.fake_name)
		managers.hud:update_name_label_by_peer(me)
	end
end

--updates players format
if _G["ExperienceManager"] and _G["ExperienceManager"] ~= nil then
	function ExperienceManager:gui_string(level, rank, offset)
		offset = offset or 0
		local gui_string
		local rank_string

		load_data()

		if rank == managers.experience:current_rank() and CommandManager.config.spoof_rank and level == managers.experience:current_level() and CommandManager.config.spoof_level then
			if rank > 0 then
				rank_string = string.format("%s (%s)", self:rank_string(rank), self:rank_string(CommandManager.config.fake_rank, false)) or ""
				gui_string = string.format("%s - %s (%s)", rank_string, tostring(level), tostring(CommandManager.config.fake_level))
			else
				gui_string = string.format("%s (%s)", tostring(level), tostring(CommandManager.config.fake_level))
			end
		else
			if rank > 0 then
				rank_string = string.format("%s (%s)", self:rank_string(rank), self:rank_string(rank, false)) or ""
				gui_string = string.format("%s - %s", rank_string, tostring(level))
			else
				gui_string = tostring(level)
			end
		end

		local rank_color_range = {{
			start = offset,
			stop = offset+utf8.len(rank_string),
			color = tweak_data.screen_colors.infamy_color
		}}
		return gui_string, rank_color_range
	end
end

-- lobby only
if _G["MenuComponentManager"] and _G["MenuComponentManager"] ~= nil then
	local orig_update_lobby = MenuComponentManager.update_contract_character_menu_state
	function MenuComponentManager:update_contract_character_menu_state(...)
		orig_update_lobby(self, ...)
		update_everyones_hud()
	end
end

-- when someone join client/host
if _G["NetworkManager"] and _G["NetworkManager"] ~= nil then
	Hooks:PostHook(NetworkManager, "on_peer_added", mod_name .. "hook_name_spoofer_on_peer_added", function(self, peer, peer_id)
		update_everyones_hud()
	end)
end

if _G["NetworkPeer"] and _G["NetworkPeer"] ~= nil then
	function NetworkPeer:real_name()
		if not self._real_name then
			self._real_name = Steam:username(self._user_id)
		end
		return self._real_name
	end

	-- myself in lobby
	Hooks:PostHook(NetworkPeer, "sync_lobby_data", mod_name .. "hook_name_spoofer_sync_lobby_data", function(self, peer)
		update_everyones_hud()
	end)
end

if _G["GamePlayCentralManager"] and _G["GamePlayCentralManager"] ~= nil then
	Hooks:PostHook(GamePlayCentralManager, "start_heist_timer", mod_name .. "hook_name_spoofer_start_heist_timer", function(self)
		update_everyones_hud()
	end)
end

if _G["ConnectionNetworkHandler"] and _G["ConnectionNetworkHandler"] ~= nil then
	Hooks:PreHook(ConnectionNetworkHandler, "kick_peer", mod_name .. "hook_name_spoofer_kick_peer", function(self, peer_id, message_id, sender)
		update_everyones_hud()
	end)

	--notify on someone else got a fake name
	function ConnectionNetworkHandler:request_player_name_reply(name, sender)
		self[mod_name .. "stored_names"] = self[mod_name .. "stored_names"] or {}
		local peer = self._verify_sender(sender) or {}

		if peer._user_id and self[mod_name .. "stored_names"][peer._user_id] == nil then
			local real_name = peer:real_name()
			self[mod_name .. "stored_names"][peer._user_id] = real_name

			if real_name and tostring(name) ~= real_name then
				DelayedCalls:Add(mod_name .. "request_player_name_reply" .. peer._user_id, 5, function()
					if managers.chat then
						managers.chat:_receive_message(1, "Name Spoof", string.format("%s's steam name did not match with their game username: %s", real_name, name), tweak_data.system_chat_color)
					end
				end)

				peer:set_name(string.format("%s (%s)", real_name, name))
			else
				peer:set_name(real_name)
			end
		end
	end
end