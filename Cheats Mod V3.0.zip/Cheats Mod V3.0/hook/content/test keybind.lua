
--CommandManager:vis("test")

--managers.mission._fading_debug_output:script().log(tostring(Network:get_ip_address_from_user_id(managers.network:session():peer(1):user_id())), Color.green)
managers.mission._fading_debug_output:script().log(tostring(debug.getmetatable(Network):get_ip_address_from_user_id(managers.network:session():peer(1):user_id())), Color.blue)